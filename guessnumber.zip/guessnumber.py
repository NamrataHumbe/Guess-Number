import random
print("#0# WELCOME TO SK GAME #0#")
print("*#* You have five chances *#*")
n=True
while(n):
    n=int(input("Enter a number to set the number in range from 1 to:"))
    a=random.randint(1,n)
    count=1
    while(a):    # a=random.randint(1,n)
        b=int(input("Try to enter a equivalent number to guess the number:"))
        if(a!=b and count<=4):
            if(a>b):

                print("Enter a greater number to win\nTry again..")
                count+=1
            else:
                print("Enter a less number to win\nTry again..")
                count+=1
        else:
            if(a==b):
                print("YOU WIN, you guess the number in",count,"trial")
                print("You want to play again (Y/N)")
                play_again=input("Enter your choice:")
                if(play_again=="Y" or play_again=="y"):
                    count=1
                    break
                else:
                    n=False
                    print("Thank you to play game")
                    break
            else:
                print("You loose the game")
                print("You are not guess the number:",a)
                print("You want to play again (Y/N)")
                play_again=input("Enter your choice:")
                if(play_again=="Y" or "y"):
                    count=1
                    break
                else:
                    n=False
                    print("Thank you to play game")
                    break



